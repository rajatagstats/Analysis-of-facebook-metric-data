```R
MAPE = function(ycap,y)
{
  cat('MAPE',mean(abs((y - ycap)/y)))
}
# Data importing
X=read.csv("dataset_Facebook.csv",sep=";",header=TRUE,na.string = '?' )
head(X)
```


<table>
<thead><tr><th scope=col>Page.total.likes</th><th scope=col>Type</th><th scope=col>Category</th><th scope=col>Post.Month</th><th scope=col>Post.Weekday</th><th scope=col>Post.Hour</th><th scope=col>Paid</th><th scope=col>Lifetime.Post.Total.Reach</th><th scope=col>Lifetime.Post.Total.Impressions</th><th scope=col>Lifetime.Engaged.Users</th><th scope=col>Lifetime.Post.Consumers</th><th scope=col>Lifetime.Post.Consumptions</th><th scope=col>Lifetime.Post.Impressions.by.people.who.have.liked.your.Page</th><th scope=col>Lifetime.Post.reach.by.people.who.like.your.Page</th><th scope=col>Lifetime.People.who.have.liked.your.Page.and.engaged.with.your.post</th><th scope=col>comment</th><th scope=col>like</th><th scope=col>share</th><th scope=col>Total.Interactions</th></tr></thead>
<tbody>
	<tr><td>139441</td><td>Photo </td><td>2     </td><td>12    </td><td>4     </td><td> 3    </td><td>0     </td><td> 2752 </td><td> 5091 </td><td> 178  </td><td> 109  </td><td> 159  </td><td> 3078 </td><td> 1640 </td><td> 119  </td><td> 4    </td><td>  79  </td><td> 17   </td><td> 100  </td></tr>
	<tr><td>139441</td><td>Status</td><td>2     </td><td>12    </td><td>3     </td><td>10    </td><td>0     </td><td>10460 </td><td>19057 </td><td>1457  </td><td>1361  </td><td>1674  </td><td>11710 </td><td> 6112 </td><td>1108  </td><td> 5    </td><td> 130  </td><td> 29   </td><td> 164  </td></tr>
	<tr><td>139441</td><td>Photo </td><td>3     </td><td>12    </td><td>3     </td><td> 3    </td><td>0     </td><td> 2413 </td><td> 4373 </td><td> 177  </td><td> 113  </td><td> 154  </td><td> 2812 </td><td> 1503 </td><td> 132  </td><td> 0    </td><td>  66  </td><td> 14   </td><td>  80  </td></tr>
	<tr><td>139441</td><td>Photo </td><td>2     </td><td>12    </td><td>2     </td><td>10    </td><td>1     </td><td>50128 </td><td>87991 </td><td>2211  </td><td> 790  </td><td>1119  </td><td>61027 </td><td>32048 </td><td>1386  </td><td>58    </td><td>1572  </td><td>147   </td><td>1777  </td></tr>
	<tr><td>139441</td><td>Photo </td><td>2     </td><td>12    </td><td>2     </td><td> 3    </td><td>0     </td><td> 7244 </td><td>13594 </td><td> 671  </td><td> 410  </td><td> 580  </td><td> 6228 </td><td> 3200 </td><td> 396  </td><td>19    </td><td> 325  </td><td> 49   </td><td> 393  </td></tr>
	<tr><td>139441</td><td>Status</td><td>2     </td><td>12    </td><td>1     </td><td> 9    </td><td>0     </td><td>10472 </td><td>20849 </td><td>1191  </td><td>1073  </td><td>1389  </td><td>16034 </td><td> 7852 </td><td>1016  </td><td> 1    </td><td> 152  </td><td> 33   </td><td> 186  </td></tr>
</tbody>
</table>




```R
colnames(X)
dim(X) #whole data dimension
```


<ol class=list-inline>
	<li>'Page.total.likes'</li>
	<li>'Type'</li>
	<li>'Category'</li>
	<li>'Post.Month'</li>
	<li>'Post.Weekday'</li>
	<li>'Post.Hour'</li>
	<li>'Paid'</li>
	<li>'Lifetime.Post.Total.Reach'</li>
	<li>'Lifetime.Post.Total.Impressions'</li>
	<li>'Lifetime.Engaged.Users'</li>
	<li>'Lifetime.Post.Consumers'</li>
	<li>'Lifetime.Post.Consumptions'</li>
	<li>'Lifetime.Post.Impressions.by.people.who.have.liked.your.Page'</li>
	<li>'Lifetime.Post.reach.by.people.who.like.your.Page'</li>
	<li>'Lifetime.People.who.have.liked.your.Page.and.engaged.with.your.post'</li>
	<li>'comment'</li>
	<li>'like'</li>
	<li>'share'</li>
	<li>'Total.Interactions'</li>
</ol>




<ol class=list-inline>
	<li>500</li>
	<li>19</li>
</ol>




```R
#shortening column names
colnames(X)[8:15]=c('Total.Reach','Total.Impressions','Lifetime.Engaged.Users','Consumers','Consumptions','Impressions.liked','Reach.liked','People.engaged.liked')
colnames(X)#checking column names after shortening
```


<ol class=list-inline>
	<li>'Page.total.likes'</li>
	<li>'Type'</li>
	<li>'Category'</li>
	<li>'Post.Month'</li>
	<li>'Post.Weekday'</li>
	<li>'Post.Hour'</li>
	<li>'Paid'</li>
	<li>'Total.Reach'</li>
	<li>'Total.Impressions'</li>
	<li>'Lifetime.Engaged.Users'</li>
	<li>'Consumers'</li>
	<li>'Consumptions'</li>
	<li>'Impressions.liked'</li>
	<li>'Reach.liked'</li>
	<li>'People.engaged.liked'</li>
	<li>'comment'</li>
	<li>'like'</li>
	<li>'share'</li>
	<li>'Total.Interactions'</li>
</ol>




```R
#from the information in the it is given that the column 'Total.Interactions' is sum of 'like', 'comment' and 'share'
#so, these four variables are redundant and we only use 'Total.Interaction' and exclude other 3
X=X[,-c(which(colnames(X)=='like'),which(colnames(X)=='share'),which(colnames(X)=='comment'))]
dim(X)
```


<ol class=list-inline>
	<li>500</li>
	<li>16</li>
</ol>




```R
library(skimr)
```


```R
skim(X)
```

    -- Data Summary ------------------------
                               Values
    Name                       X     
    Number of rows             500   
    Number of columns          16    
    _______________________          
    Column type frequency:           
      factor                   1     
      numeric                  15    
    ________________________         
    Group variables            None  
    
    -- Variable type: factor -------------------------------------------------------
    # A tibble: 1 x 6
      skim_variable n_missing complete_rate ordered n_unique
    * <chr>             <int>         <dbl> <lgl>      <int>
    1 Type                  0             1 FALSE          4
      top_counts                        
    * <chr>                             
    1 Pho: 426, Sta: 45, Lin: 22, Vid: 7
    
    -- Variable type: numeric ------------------------------------------------------
    # A tibble: 15 x 11
       skim_variable          n_missing complete_rate       mean        sd    p0
     * <chr>                      <int>         <dbl>      <dbl>     <dbl> <dbl>
     1 Page.total.likes               0         1     123194.    16273.    81370
     2 Category                       0         1          1.88      0.853     1
     3 Post.Month                     0         1          7.04      3.31      1
     4 Post.Weekday                   0         1          4.15      2.03      1
     5 Post.Hour                      0         1          7.84      4.37      1
     6 Paid                           1         0.998      0.279     0.449     0
     7 Total.Reach                    0         1      13903.    22741.      238
     8 Total.Impressions              0         1      29586.    76803.      570
     9 Lifetime.Engaged.Users         0         1        920.      985.        9
    10 Consumers                      0         1        799.      883.        9
    11 Consumptions                   0         1       1415.     2001.        9
    12 Impressions.liked              0         1      16766.    59791.      567
    13 Reach.liked                    0         1       6585.     7682.      236
    14 People.engaged.liked           0         1        610.      613.        9
    15 Total.Interactions             0         1        212.      380.        0
           p25     p50     p75    p100 hist 
     *   <dbl>   <dbl>   <dbl>   <dbl> <chr>
     1 112676  129600  136393   139441 <U+2581><U+2581><U+2582><U+2582><U+2587>
     2      1       2       3        3 <U+2587><U+2581><U+2585><U+2581><U+2586>
     3      4       7      10       12 <U+2585><U+2585><U+2585><U+2583><U+2587>
     4      2       4       6        7 <U+2586><U+2583><U+2583><U+2583><U+2587>
     5      3       9      11       23 <U+2587><U+2582><U+2587><U+2581><U+2581>
     6      0       0       1        1 <U+2587><U+2581><U+2581><U+2581><U+2583>
     7   3315    5281   13168   180480 <U+2587><U+2581><U+2581><U+2581><U+2581>
     8   5695.   9051   22086. 1110282 <U+2587><U+2581><U+2581><U+2581><U+2581>
     9    394.    626.   1062    11452 <U+2587><U+2581><U+2581><U+2581><U+2581>
    10    332.    552.    956.   11328 <U+2587><U+2581><U+2581><U+2581><U+2581>
    11    509.    851    1463    19779 <U+2587><U+2581><U+2581><U+2581><U+2581>
    12   3970.   6256.  14860. 1107833 <U+2587><U+2581><U+2581><U+2581><U+2581>
    13   2182.   3417    7989    51456 <U+2587><U+2581><U+2581><U+2581><U+2581>
    14    291     412     656.    4376 <U+2587><U+2581><U+2581><U+2581><U+2581>
    15     71     124.    228.    6334 <U+2587><U+2581><U+2581><U+2581><U+2581>
    


```R
#see that there is 500 obsn, 16 variables, one categorical, 15 numeric variable
#one missing value in 'Paid'

#We will exculde the single observation contains a missing value
which(is.na(X$Paid)==T) #500
```


500



```R
#deleting 500th observation 
X=X[-500,]
dim(X)
```


<ol class=list-inline>
	<li>499</li>
	<li>16</li>
</ol>




```R
#Actually there are 6 categorical variable namely 'Type', 'Category', 'Post.Month'
#'Post.Weekday', 'Post.Hour' and 'Paid' needed to convert into categorical type
X$Type=as.factor(X$Type)
X$Category=as.factor(X$Category)
X$Paid=as.factor(X$Paid)
X$Post.Month=as.factor(X$Post.Month)
X$Post.Hour=as.factor(X$Post.Hour)
X$Post.Weekday=as.factor(X$Post.Weekday)
```


```R
#let's again see the variables and their summary
skim(X)
#now, no missing value 6 categorical , 10 numeric variable

```

    -- Data Summary ------------------------
                               Values
    Name                       X     
    Number of rows             499   
    Number of columns          16    
    _______________________          
    Column type frequency:           
      factor                   6     
      numeric                  10    
    ________________________         
    Group variables            None  
    
    -- Variable type: factor -------------------------------------------------------
    # A tibble: 6 x 6
      skim_variable n_missing complete_rate ordered n_unique
    * <chr>             <int>         <dbl> <lgl>      <int>
    1 Type                  0             1 FALSE          4
    2 Category              0             1 FALSE          3
    3 Post.Month            0             1 FALSE         12
    4 Post.Weekday          0             1 FALSE          7
    5 Post.Hour             0             1 FALSE         22
    6 Paid                  0             1 FALSE          2
      top_counts                        
    * <chr>                             
    1 Pho: 425, Sta: 45, Lin: 22, Vid: 7
    2 1: 215, 3: 155, 2: 129            
    3 10: 60, 7: 52, 4: 50, 12: 50      
    4 7: 82, 6: 81, 4: 71, 1: 68        
    5 3: 105, 10: 78, 13: 52, 11: 44    
    6 0: 360, 1: 139                    
    
    -- Variable type: numeric ------------------------------------------------------
    # A tibble: 10 x 11
       skim_variable          n_missing complete_rate    mean     sd    p0     p25
     * <chr>                      <int>         <dbl>   <dbl>  <dbl> <dbl>   <dbl>
     1 Page.total.likes               0             1 123278. 16181. 81370 113028 
     2 Total.Reach                    0             1  13923. 22759.   238   3308 
     3 Total.Impressions              0             1  29631. 76874.   570   5690.
     4 Lifetime.Engaged.Users         0             1    921.   986.     9    394.
     5 Consumers                      0             1    799.   883.     9    332 
     6 Consumptions                   0             1   1416.  2002.     9    508.
     7 Impressions.liked              0             1  16792. 59848.   567   3982.
     8 Reach.liked                    0             1   6594.  7687.   236   2179 
     9 People.engaged.liked           0             1    611.   613.     9    291 
    10 Total.Interactions             0             1    212.   381.     0     71 
          p50     p75    p100 hist 
     *  <dbl>   <dbl>   <dbl> <chr>
     1 129600 136393   139441 <U+2581><U+2581><U+2582><U+2582><U+2587>
     2   5282  13184   180480 <U+2587><U+2581><U+2581><U+2581><U+2581>
     3   9067  22213  1110282 <U+2587><U+2581><U+2581><U+2581><U+2581>
     4    626   1062    11452 <U+2587><U+2581><U+2581><U+2581><U+2581>
     5    554    958    11328 <U+2587><U+2581><U+2581><U+2581><U+2581>
     6    852   1465    19779 <U+2587><U+2581><U+2581><U+2581><U+2581>
     7   6258  14929  1107833 <U+2587><U+2581><U+2581><U+2581><U+2581>
     8   3422   7994    51456 <U+2587><U+2581><U+2581><U+2581><U+2581>
     9    413    656.    4376 <U+2587><U+2581><U+2581><U+2581><U+2581>
    10    124    229     6334 <U+2587><U+2581><U+2581><U+2581><U+2581>
    


```R
#splitting into train and test
set.seed(197)
ind=sample(499,499*.8) # selecting randomly approx. 80% of observation from 499 observation
X_train=X[ind,]
X_test=X[-ind,]
dim(X_train)  #399 16
dim(X_test)   #100 16

#train set
y=X_train[,which(colnames(X)=='Lifetime.Engaged.Users')]
X=X_train[,-which(colnames(X)=='Lifetime.Engaged.Users')]

#test set
y_test=X_test[,which(colnames(X_test)=='Lifetime.Engaged.Users')]
X_test=X_test[,-which(colnames(X_test)=='Lifetime.Engaged.Users')]


dim(X)  #now dimension of X is 399 x 15
```


<ol class=list-inline>
	<li>399</li>
	<li>16</li>
</ol>




<ol class=list-inline>
	<li>100</li>
	<li>16</li>
</ol>




<ol class=list-inline>
	<li>399</li>
	<li>15</li>
</ol>




```R

cat_col=c(2,3,4,5,6,7) # a Variable containing the column indices of categorical variable

cat_col#box plot and frequency tables for categorical variable
data=cbind.data.frame(y,X)
colnames(data)[1]="Lifetime.Engaged.Users"

```


<ol class=list-inline>
	<li>2</li>
	<li>3</li>
	<li>4</li>
	<li>5</li>
	<li>6</li>
	<li>7</li>
</ol>




```R
library(ggplot2)
library(RColorBrewer)
```


```R
#Handling Type Variable 
ggplot(data,aes(x=Type,y=Lifetime.Engaged.Users,fill=Type))+
  geom_boxplot()+scale_fill_brewer(palette = "Dark2")+theme_classic()
table(X[,2])
#'Photo' consists many outliers. 'Status', 'Link', 'Video' have long tail
#clearly we see a ordering i.e. y increases from Link to Photo to Status to Video
#so, we can assign a increasing number to these labels of category
X[,2]=factor(X[,2],levels = c('Link','Photo','Status','Video'),labels = c(1,2,3,4))
X[,2]=as.numeric(X[,2])
```


    
      Link  Photo Status  Video 
        19    345     32      3 



    
![png](output_13_1.png)
    



```R


ggplot(data,aes(x=Category,y=Lifetime.Engaged.Users,fill=Category))+
  geom_boxplot()+scale_fill_brewer(palette = "Dark2")+theme_classic()
table(X[,3])
#each label has outliers, category 1,2,3 contain 174,101,124 respectively
#category 2 has long tail. all levels have almost same central tendency

```


    
      1   2   3 
    174 101 124 



    
![png](output_14_1.png)
    



```R

ggplot(data,aes(x=Paid,y=Lifetime.Engaged.Users,fill=Paid))+
  geom_boxplot()+scale_fill_brewer(palette = "Dark2")+theme_classic()
table(X[,7])
#each label has many outliers , paid 0 is more frequent (301)

```


    
      0   1 
    301  98 



    
![png](output_15_1.png)
    



```R
ggplot(data,aes(x=Post.Month,y=Lifetime.Engaged.Users,fill=Post.Month))+
  geom_boxplot()+scale_fill_brewer(palette = "Paired")+theme_classic()
table(X[,4])
#most frequent months are oct(50), dec(40)
#seeing the graph we can group our months into three groups considering their central tendency
#(1,2),(3,4,5,6,,7),(8,9,10,11,12)
library(plyr)
X[,4]=revalue(X[,4],c('1'='group1','2'='group1','3'='group2','4'='group2','5'='group2','6'='group2','7'='group2','8'='group3','9'='group3','10'='group3','11'='group3','12'='group3'))

```


    
     1  2  3  4  5  6  7  8  9 10 11 12 
    21 24 29 37 29 40 38 26 32 50 33 40 



    
![png](output_16_1.png)
    



```R
ggplot(data,aes(x=Post.Hour,y=Lifetime.Engaged.Users,fill=Post.Hour))+
  geom_boxplot()+theme_classic()
table(X[,6])
#it is clear that there are only one observation in hour 16,19,20,22,hour 23 has no value
#seeing the plot we can group the hours in evening(15-22),night(23-4),morning(5-9),day(10-14)
X[,6]=revalue(X[,6],c('23'='night','1'='night','2'='night','3'='night','4'='night','5'='morning','6'='morning','7'='morning','8'='morning','9'='morning','10'='day','11'='day','12'='day','13'='day','14'='day','15'='evening','16'='evening','17'='evening','18'='evening','19'='evening','20'='evening','22'='evening'))


```


    
     1  2  3  4  5  6  7  8  9 10 11 12 13 14 15 16 17 18 19 20 22 23 
     4 30 85 29 11 14  9  9 25 63 34 21 40 11  4  1  3  3  1  1  1  0 



    
![png](output_17_1.png)
    



```R

ggplot(data,aes(x=Post.Weekday,y=Lifetime.Engaged.Users,fill=Post.Weekday))+
  geom_boxplot()+scale_fill_brewer(palette = "Dark2")+theme_classic()
table(X[,5])
#all the observations are almost equally distributed among the levels, their central tendency also near about same but among them day 4 has highest central tendency
# here we can group these into weekday and weekened
X[,5]=revalue(X[,5],c('1'='weekday','2'='weekday','3'='weekday','4'='weekday','5'='weekday','6'='weekend','7'='weekend'))

```


    
     1  2  3  4  5  6  7 
    58 53 49 56 52 68 63 



    
![png](output_18_1.png)
    



```R

#now our categorical column has decreased
cat_col=c(3,4,5,6,7)
#Normalization
X[,-cat_col]=scale(X[,-cat_col])
#correlation among numeric variables
pairs(X[,-cat_col])
cor(X[,-cat_col])
cor(X[,-cat_col],y)

```


<table>
<thead><tr><th></th><th scope=col>Page.total.likes</th><th scope=col>Type</th><th scope=col>Total.Reach</th><th scope=col>Total.Impressions</th><th scope=col>Consumers</th><th scope=col>Consumptions</th><th scope=col>Impressions.liked</th><th scope=col>Reach.liked</th><th scope=col>People.engaged.liked</th><th scope=col>Total.Interactions</th></tr></thead>
<tbody>
	<tr><th scope=row>Page.total.likes</th><td> 1.00000000</td><td>0.19588706 </td><td>-0.07898343</td><td>-0.10082818</td><td>-0.1810288 </td><td>-0.1309026 </td><td>-0.10701146</td><td>-0.08373285</td><td>0.01319878 </td><td>0.02616364 </td></tr>
	<tr><th scope=row>Type</th><td> 0.19588706</td><td>1.00000000 </td><td> 0.04969194</td><td> 0.02943978</td><td> 0.4884293 </td><td> 0.2350372 </td><td> 0.03292222</td><td> 0.14945310</td><td>0.51282596 </td><td>0.05934420 </td></tr>
	<tr><th scope=row>Total.Reach</th><td>-0.07898343</td><td>0.04969194 </td><td> 1.00000000</td><td> 0.65387062</td><td> 0.4654033 </td><td> 0.2620303 </td><td> 0.31776237</td><td> 0.73681831</td><td>0.38987190 </td><td>0.48429775 </td></tr>
	<tr><th scope=row>Total.Impressions</th><td>-0.10082818</td><td>0.02943978 </td><td> 0.65387062</td><td> 1.00000000</td><td> 0.3335410 </td><td> 0.2032278 </td><td> 0.87493643</td><td> 0.64684875</td><td>0.32973666 </td><td>0.32763053 </td></tr>
	<tr><th scope=row>Consumers</th><td>-0.18102875</td><td>0.48842927 </td><td> 0.46540329</td><td> 0.33354095</td><td> 1.0000000 </td><td> 0.5895780 </td><td> 0.28045424</td><td> 0.59501859</td><td>0.91507175 </td><td>0.41823366 </td></tr>
	<tr><th scope=row>Consumptions</th><td>-0.13090257</td><td>0.23503724 </td><td> 0.26203031</td><td> 0.20322781</td><td> 0.5895780 </td><td> 1.0000000 </td><td> 0.17131101</td><td> 0.34541205</td><td>0.53381412 </td><td>0.22896113 </td></tr>
	<tr><th scope=row>Impressions.liked</th><td>-0.10701146</td><td>0.03292222 </td><td> 0.31776237</td><td> 0.87493643</td><td> 0.2804542 </td><td> 0.1713110 </td><td> 1.00000000</td><td> 0.59772542</td><td>0.33418363 </td><td>0.29146004 </td></tr>
	<tr><th scope=row>Reach.liked</th><td>-0.08373285</td><td>0.14945310 </td><td> 0.73681831</td><td> 0.64684875</td><td> 0.5950186 </td><td> 0.3454121 </td><td> 0.59772542</td><td> 1.00000000</td><td>0.66565469 </td><td>0.64449764 </td></tr>
	<tr><th scope=row>People.engaged.liked</th><td> 0.01319878</td><td>0.51282596 </td><td> 0.38987190</td><td> 0.32973666</td><td> 0.9150718 </td><td> 0.5338141 </td><td> 0.33418363</td><td> 0.66565469</td><td>1.00000000 </td><td>0.52950544 </td></tr>
	<tr><th scope=row>Total.Interactions</th><td> 0.02616364</td><td>0.05934420 </td><td> 0.48429775</td><td> 0.32763053</td><td> 0.4182337 </td><td> 0.2289611 </td><td> 0.29146004</td><td> 0.64449764</td><td>0.52950544 </td><td>1.00000000 </td></tr>
</tbody>
</table>




<table>
<tbody>
	<tr><th scope=row>Page.total.likes</th><td>-0.1404654</td></tr>
	<tr><th scope=row>Type</th><td> 0.4348998</td></tr>
	<tr><th scope=row>Total.Reach</th><td> 0.5419739</td></tr>
	<tr><th scope=row>Total.Impressions</th><td> 0.3746976</td></tr>
	<tr><th scope=row>Consumers</th><td> 0.9695748</td></tr>
	<tr><th scope=row>Consumptions</th><td> 0.5618013</td></tr>
	<tr><th scope=row>Impressions.liked</th><td> 0.3151980</td></tr>
	<tr><th scope=row>Reach.liked</th><td> 0.6906750</td></tr>
	<tr><th scope=row>People.engaged.liked</th><td> 0.9288043</td></tr>
	<tr><th scope=row>Total.Interactions</th><td> 0.6205491</td></tr>
</tbody>
</table>




    
![png](output_19_2.png)
    



```R
library(fastDummies)
```


```R

# indicator Variable
library(fastDummies)
length(cat_col) #5
X=dummy_cols(X,select_columns =colnames(X)[ cat_col],remove_first_dummy = T,remove_selected_columns = T)
dim(X)  #399 x 19
```


5



<ol class=list-inline>
	<li>399</li>
	<li>19</li>
</ol>




```R
# a function for modification in test set which include categorical variable modification, normalization, indicator variable
convert=function(X){
  X[,2]=factor(X[,2],levels = c('Link','Photo','Status','Video'),labels = c(1,2,3,4))
  X[,2]=as.numeric(X[,2])
  X[,4]=revalue(X[,4],c('1'='group1','2'='group1','3'='group2','4'='group2','5'='group2','6'='group2','7'='group2','8'='group3','9'='group3','10'='group3','11'='group3','12'='group3'))
  X[,6]=revalue(X[,6],c('23'='night','1'='night','2'='night','3'='night','4'='night','5'='morning','6'='morning','7'='morning','8'='morning','9'='morning','10'='day','11'='day','12'='day','13'='day','14'='day','15'='evening','16'='evening','17'='evening','18'='evening','19'='evening','20'='evening','22'='evening'))
  X[,5]=revalue(X[,5],c('1'='weekday','2'='weekday','3'='weekday','4'='weekday','5'='weekday','6'='weekend','7'='weekend'))
  cat_col=c(3,4,5,6,7)
  X[,-cat_col]=scale(X[,-cat_col])
  X=dummy_cols(X,select_columns =colnames(X)[ cat_col],remove_first_dummy = T,remove_selected_columns = T)
  
  return(X)
}
X_test=convert(X_test)
```


```R
p=(dim(X))[2]   
p     #no. of predictors   19
n=(dim(X))[1]
n     #no. of observation  399
dim(X_test)
```


19



399



<ol class=list-inline>
	<li>100</li>
	<li>19</li>
</ol>




```R
install.packages("olsrr")
```

    Warning message:
    "package 'olsrr' is in use and will not be installed"


```R
library(olsrr)
my_data=cbind(y,X)
model=lm(y~.,data=my_data)
summary(model)      # multiple R squared=.9971,  Adjusted R square=0.9969
dim(my_data)  #399  19
predictions <- predict(model, X_test)
MAPE(predictions,y_test)  #MAPE 0.3498  
```


    
    Call:
    lm(formula = y ~ ., data = my_data)
    
    Residuals:
        Min      1Q  Median      3Q     Max 
    -316.49  -14.60    1.52   14.07  233.63 
    
    Coefficients:
                         Estimate Std. Error t value Pr(>|t|)    
    (Intercept)          873.5529    14.7260  59.321  < 2e-16 ***
    Page.total.likes       4.0530     5.3029   0.764   0.4452    
    Type                  -2.3758     2.8198  -0.843   0.4000    
    Total.Reach           58.9381     8.6817   6.789 4.38e-11 ***
    Total.Impressions    -57.6205    11.0707  -5.205 3.19e-07 ***
    Consumers            605.6521     8.7876  68.922  < 2e-16 ***
    Consumptions          -5.1427     2.7782  -1.851   0.0649 .  
    Impressions.liked     41.2835    10.1558   4.065 5.84e-05 ***
    Reach.liked          -14.5050     7.0468  -2.058   0.0402 *  
    People.engaged.liked  47.6695     9.2135   5.174 3.72e-07 ***
    Total.Interactions   178.2323     3.2223  55.312  < 2e-16 ***
    Category_2             0.8342     6.1741   0.135   0.8926    
    Category_3             1.9166     5.7475   0.333   0.7390    
    Post.Month_group2    -17.4648    12.7840  -1.366   0.1727    
    Post.Month_group3    -15.2055    18.0433  -0.843   0.3999    
    Post.Weekday_weekend  -0.9547     4.6193  -0.207   0.8364    
    Post.Hour_morning     12.3763     6.3255   1.957   0.0511 .  
    Post.Hour_day          2.8415     4.8098   0.591   0.5550    
    Post.Hour_evening     15.1271    13.1813   1.148   0.2519    
    Paid_1                 8.0671     4.9500   1.630   0.1040    
    ---
    Signif. codes:  0 '***' 0.001 '**' 0.01 '*' 0.05 '.' 0.1 ' ' 1
    
    Residual standard error: 41.66 on 379 degrees of freedom
    Multiple R-squared:  0.9971,	Adjusted R-squared:  0.9969 
    F-statistic:  6843 on 19 and 379 DF,  p-value: < 2.2e-16
    



<ol class=list-inline>
	<li>399</li>
	<li>20</li>
</ol>



    MAPE 0.3498235


```R

#leverage points
hat_value=hatvalues(model)
par(mfrow=c(1,1))
plot(hat_value,xlab ="observation",ylab="hat_values",col=(hat_value>0.6)+1)
abline(h=0.3,col="red")
lev_point=which(hat_value>0.3)      # it provides row no of data corresponding to which high hat values
length(lev_point)  # 5
my_data1=my_data[-lev_point,]
#c=which(colSums(my_data1)==0)
#c
#my_data1=my_data1[,-c]
#X.test=X_test[,-(c-1)]
row.names(my_data1)=as.character(seq(1,dim(my_data1)[1]))   # assigning row names to each row of data
model1=lm(y~.,my_data1)
summary(model1)
dim(my_data1)
predictions <- predict(model1, X_test)
MAPE(predictions,y_test) ##MAPE 0.3366
```


5



    
    Call:
    lm(formula = y ~ ., data = my_data1)
    
    Residuals:
        Min      1Q  Median      3Q     Max 
    -338.15  -13.59    2.83   14.66  215.62 
    
    Coefficients:
                         Estimate Std. Error t value Pr(>|t|)    
    (Intercept)          887.2886    14.5272  61.078  < 2e-16 ***
    Page.total.likes       8.3576     5.1629   1.619  0.10634    
    Type                  -3.2578     2.7032  -1.205  0.22890    
    Total.Reach           68.6141     9.4654   7.249 2.43e-12 ***
    Total.Impressions    -89.5268    16.6509  -5.377 1.34e-07 ***
    Consumers            602.7834     8.6434  69.740  < 2e-16 ***
    Consumptions          -6.4668     3.4036  -1.900  0.05820 .  
    Impressions.liked     77.7228    23.9431   3.246  0.00128 ** 
    Reach.liked          -22.2853     9.3869  -2.374  0.01810 *  
    People.engaged.liked  53.6517     9.0813   5.908 7.80e-09 ***
    Total.Interactions   181.3531     3.1814  57.003  < 2e-16 ***
    Category_2            -2.0362     5.9315  -0.343  0.73157    
    Category_3             0.9582     5.5281   0.173  0.86249    
    Post.Month_group2    -28.7818    12.5602  -2.292  0.02249 *  
    Post.Month_group3    -30.4241    17.6886  -1.720  0.08626 .  
    Post.Weekday_weekend  -2.5476     4.4455  -0.573  0.56694    
    Post.Hour_morning     10.8332     6.0797   1.782  0.07558 .  
    Post.Hour_day          2.3427     4.6280   0.506  0.61302    
    Post.Hour_evening     20.4061    12.7623   1.599  0.11068    
    Paid_1                 7.4240     4.7673   1.557  0.12025    
    ---
    Signif. codes:  0 '***' 0.001 '**' 0.01 '*' 0.05 '.' 0.1 ' ' 1
    
    Residual standard error: 39.77 on 374 degrees of freedom
    Multiple R-squared:  0.9972,	Adjusted R-squared:  0.9971 
    F-statistic:  7004 on 19 and 374 DF,  p-value: < 2.2e-16
    



<ol class=list-inline>
	<li>394</li>
	<li>20</li>
</ol>



    MAPE 0.336696


    
![png](output_26_4.png)
    



```R


# cooks distance
cd=cooks.distance(model1)
plot(cd,xlab="observation",ylab="cooks distance")
abline(h=0.25,col="red")
inf_cd=which(cd>0.25)
length(inf_cd) #3
ols_plot_cooksd_bar(model1)
```


3



    
![png](output_27_1.png)
    



    
![png](output_27_2.png)
    



```R

# DFFITS
df_fit=dffits(model1)
plot(1:length(df_fit),df_fit,xlab="observation",ylab="DFFIT")
abline(h=c(2.5,-2.5),col="red")
ols_plot_dffits(model1)
influence_DFFIT=which(abs(df_fit)>2.5)
length(influence_DFFIT)  #3
```


    
![png](output_28_0.png)
    



3



    
![png](output_28_2.png)
    



```R



####DFBETA######
DFBETA_ij=dfbetas(model1)
dim(my_data1)  #394 20
influence_DFBETA=c()
for(j in 2:10)
  influence_DFBETA=c(influence_DFBETA ,which(abs(DFBETA_ij[,j])>2/sqrt(394)) )
influence_DFBETA = as.numeric(names(which( table(influence_DFBETA)>=7) ) )
length(influence_DFBETA) #10
```


<ol class=list-inline>
	<li>394</li>
	<li>20</li>
</ol>




10



```R


#covratio
COVRATIO=covratio(model1)
par(mfrow=c(1,1))
plot(COVRATIO,main="Fig 3:COVRATIO for training data Red:influential points and Black :Non",
     col=(abs(COVRATIO-1)>1)+1,cex.main=0.85, pch=20)
abline(h=c( 1.5, 0.5) , col="red", lwd=2, lty="dotted")#check threshold
influence_COVRATIO1=which(abs(COVRATIO)>1.5)
influence_COVRATIO2=which(abs(COVRATIO)<0.4)
influence_COVRATIO=length(influence_COVRATIO1)+length(influence_COVRATIO2) # 6
influence_COVRATIO

```


6



    
![png](output_30_1.png)
    



```R

#####Final Influential#####
influential = sort(( c(inf_cd,influence_DFBETA,influence_DFFIT,influence_COVRATIO ) ))
final=as.numeric(names(which(table(influential)>=2)))
length(final)  #3
my_data2=my_data1[-final,]
which(colSums(my_data2)==0) #0
#row.names(my_data2)=as.character(seq(1,dim(my_data2)[1]))
dim(my_data2)  #391  20
```


3







<ol class=list-inline>
	<li>391</li>
	<li>20</li>
</ol>




```R


model2=lm(y~.,data=my_data2)
summary(model2)
predictions <- predict(model2, X_test)
MAPE(predictions,y_test) # MAPE 0.3260  
my_data22=my_data2

```


    
    Call:
    lm(formula = y ~ ., data = my_data2)
    
    Residuals:
         Min       1Q   Median       3Q      Max 
    -146.850  -14.496    3.641   15.071  194.887 
    
    Coefficients:
                         Estimate Std. Error t value Pr(>|t|)    
    (Intercept)           887.450     12.198  72.756  < 2e-16 ***
    Page.total.likes        7.490      4.388   1.707  0.08867 .  
    Type                   -4.490      2.268  -1.980  0.04846 *  
    Total.Reach            54.302      8.187   6.632 1.17e-10 ***
    Total.Impressions     -79.080     14.318  -5.523 6.27e-08 ***
    Consumers             613.459      7.325  83.751  < 2e-16 ***
    Consumptions           -7.498      2.853  -2.628  0.00894 ** 
    Impressions.liked     103.977     24.459   4.251 2.70e-05 ***
    Reach.liked           -27.361      8.882  -3.080  0.00222 ** 
    People.engaged.liked   45.941      7.700   5.967 5.65e-09 ***
    Total.Interactions    190.558      3.159  60.322  < 2e-16 ***
    Category_2             -7.976      5.016  -1.590  0.11263    
    Category_3             -5.887      4.695  -1.254  0.21067    
    Post.Month_group2     -20.111     10.698  -1.880  0.06092 .  
    Post.Month_group3     -20.236     14.960  -1.353  0.17700    
    Post.Weekday_weekend   -4.543      3.736  -1.216  0.22470    
    Post.Hour_morning      11.256      5.101   2.207  0.02795 *  
    Post.Hour_day           2.887      3.889   0.742  0.45836    
    Post.Hour_evening      19.565     10.705   1.828  0.06841 .  
    Paid_1                  1.378      4.031   0.342  0.73266    
    ---
    Signif. codes:  0 '***' 0.001 '**' 0.01 '*' 0.05 '.' 0.1 ' ' 1
    
    Residual standard error: 33.31 on 371 degrees of freedom
    Multiple R-squared:  0.9979,	Adjusted R-squared:  0.9978 
    F-statistic:  9192 on 19 and 371 DF,  p-value: < 2.2e-16
    


    MAPE 0.326058


```R
library(ggpubr)
```


```R

##normality checking
y=my_data2[,1]

ggdensity(y,fill='blue')+ggtitle('Density Curve')+labs(x='y')+theme_dark()
ggqqplot(y)+ggtitle('Normal Q-Q Plot')+theme_light()
```


    
![png](output_34_0.png)
    



    
![png](output_34_1.png)
    



```R
library(MASS)
```


```R
# Box-Cox transformation
z=log(y)
ggqqplot(z)+ggtitle('Normal Q-Q Plot')+theme_light()
# box cox transformation on log(y)
my_data22[,1]=z
mod_bc=lm(y~.,data=my_data22)   # model for box-cox transformation
bc=boxcox(mod_bc,lambda = seq(-2,2))   # boc-cox transformation 
best.lambda= bc$x[which(bc$y==max(bc$y))]
best.lambda  #2
shapiro.test(z^best.lambda)    #0.001265
plot(lm((z^best.lambda)~.,data=my_data22))

```


    
![png](output_36_0.png)
    



2



    
    	Shapiro-Wilk normality test
    
    data:  z^best.lambda
    W = 0.98679, p-value = 0.001265
    



    
![png](output_36_3.png)
    



    
![png](output_36_4.png)
    



    
![png](output_36_5.png)
    



    
![png](output_36_6.png)
    



    
![png](output_36_7.png)
    



```R
#excluding first 6 points
z1=sort(z)[7:392]
ggqqplot(z1)+ggtitle('Normal Q-Q Plot')+theme_light()
ggdensity(z1,fill='blue')+ggtitle('Density Curve')+theme_dark()
shapiro.test(z1) #p-value = 0.1135  so, it is normal
del_point=which(z<=sort(z)[6])

```

    Warning message:
    "Removed 1 rows containing non-finite values (stat_qq)."Warning message:
    "Removed 1 rows containing non-finite values (stat_qq_line)."Warning message:
    "Removed 1 rows containing non-finite values (stat_qq_line)."Warning message:
    "Removed 1 rows containing non-finite values (stat_density)."


    
![png](output_37_1.png)
    



    
    	Shapiro-Wilk normality test
    
    data:  z1
    W = 0.99375, p-value = 0.1135
    



    
![png](output_37_3.png)
    



```R

#new data with transformed response
my_data2[,1]=z
my_data2=my_data2[-del_point,]
colnames(my_data2)[1]='z'
dim(my_data2)   #384  20
model3=lm(z~.,data=my_data2)   #Our new or transformed model
summary(model3)
predictions <- predict(model3, X_test)
#MAPE(exp(predictions),y_test) # MAPE 0.4811202
MAPE(predictions,log(y_test))   # 0.06632
```


<ol class=list-inline>
	<li>384</li>
	<li>20</li>
</ol>




    
    Call:
    lm(formula = z ~ ., data = my_data2)
    
    Residuals:
         Min       1Q   Median       3Q      Max 
    -1.58114 -0.09024  0.05563  0.17159  0.57939 
    
    Coefficients:
                         Estimate Std. Error t value Pr(>|t|)    
    (Intercept)           6.64417    0.11310  58.744  < 2e-16 ***
    Page.total.likes     -0.03206    0.04140  -0.774  0.43916    
    Type                  0.08685    0.02109   4.119 4.71e-05 ***
    Total.Reach          -0.11060    0.07522  -1.470  0.14235    
    Total.Impressions     0.35353    0.13157   2.687  0.00754 ** 
    Consumers             0.51335    0.06738   7.618 2.25e-13 ***
    Consumptions          0.07069    0.02622   2.696  0.00734 ** 
    Impressions.liked    -0.37592    0.22474  -1.673  0.09525 .  
    Reach.liked           0.09554    0.08170   1.170  0.24296    
    People.engaged.liked -0.06062    0.07078  -0.857  0.39228    
    Total.Interactions    0.24951    0.02903   8.596 2.48e-16 ***
    Category_2            0.03722    0.04646   0.801  0.42353    
    Category_3            0.06036    0.04356   1.385  0.16677    
    Post.Month_group2    -0.10122    0.10007  -1.012  0.31244    
    Post.Month_group3    -0.32438    0.13929  -2.329  0.02041 *  
    Post.Weekday_weekend  0.01494    0.03464   0.431  0.66656    
    Post.Hour_morning    -0.02442    0.04747  -0.514  0.60729    
    Post.Hour_day        -0.01213    0.03601  -0.337  0.73641    
    Post.Hour_evening    -0.28808    0.09907  -2.908  0.00386 ** 
    Paid_1                0.07955    0.03736   2.129  0.03390 *  
    ---
    Signif. codes:  0 '***' 0.001 '**' 0.01 '*' 0.05 '.' 0.1 ' ' 1
    
    Residual standard error: 0.3059 on 364 degrees of freedom
    Multiple R-squared:  0.8439,	Adjusted R-squared:  0.8358 
    F-statistic: 103.6 on 19 and 364 DF,  p-value: < 2.2e-16
    


    MAPE 0.06632248


```R
library(lmtest)
```


```R
#heteroscedasticity
library(lmtest)
bptest(model3)  #p-value =0.5865 implies no heteroscedasticity

```


    
    	studentized Breusch-Pagan test
    
    data:  model3
    BP = 17.05, df = 19, p-value = 0.5865
    



```R
#multicollinearity
# checking Multicollinearity
X_num<-my_data2[,2:11]   # containing only numerical vectors
cor(X_num)  # from this it is clear that X2,X3,X6,X7 are highly correlate also 
#X4 and X8 are highly correlated.(indication of Multicollinearity)
```


<table>
<thead><tr><th></th><th scope=col>Page.total.likes</th><th scope=col>Type</th><th scope=col>Total.Reach</th><th scope=col>Total.Impressions</th><th scope=col>Consumers</th><th scope=col>Consumptions</th><th scope=col>Impressions.liked</th><th scope=col>Reach.liked</th><th scope=col>People.engaged.liked</th><th scope=col>Total.Interactions</th></tr></thead>
<tbody>
	<tr><th scope=row>Page.total.likes</th><td> 1.000000000</td><td>0.19183468  </td><td>-0.009042999</td><td>0.06541041  </td><td>-0.1625433  </td><td>-0.1422285  </td><td>-0.01294034 </td><td>-0.03250415 </td><td>0.04763436  </td><td>0.07884665  </td></tr>
	<tr><th scope=row>Type</th><td> 0.191834678</td><td>1.00000000  </td><td> 0.061401665</td><td>0.08524051  </td><td> 0.5153109  </td><td> 0.2798811  </td><td> 0.15531243 </td><td> 0.17069650 </td><td>0.54921531  </td><td>0.07577995  </td></tr>
	<tr><th scope=row>Total.Reach</th><td>-0.009042999</td><td>0.06140166  </td><td> 1.000000000</td><td>0.91498525  </td><td> 0.4440268  </td><td> 0.2914410  </td><td> 0.75540316 </td><td> 0.81445012 </td><td>0.38547494  </td><td>0.49295668  </td></tr>
	<tr><th scope=row>Total.Impressions</th><td> 0.065410413</td><td>0.08524051  </td><td> 0.914985250</td><td>1.00000000  </td><td> 0.3731710  </td><td> 0.2638315  </td><td> 0.83120337 </td><td> 0.76786285 </td><td>0.35050594  </td><td>0.41023113  </td></tr>
	<tr><th scope=row>Consumers</th><td>-0.162543273</td><td>0.51531085  </td><td> 0.444026792</td><td>0.37317099  </td><td> 1.0000000  </td><td> 0.6471108  </td><td> 0.47710709 </td><td> 0.56727381 </td><td>0.91019504  </td><td>0.33426659  </td></tr>
	<tr><th scope=row>Consumptions</th><td>-0.142228550</td><td>0.27988107  </td><td> 0.291441001</td><td>0.26383150  </td><td> 0.6471108  </td><td> 1.0000000  </td><td> 0.31754765 </td><td> 0.37647916 </td><td>0.58821491  </td><td>0.18892525  </td></tr>
	<tr><th scope=row>Impressions.liked</th><td>-0.012940344</td><td>0.15531243  </td><td> 0.755403165</td><td>0.83120337  </td><td> 0.4771071  </td><td> 0.3175477  </td><td> 1.00000000 </td><td> 0.91031585 </td><td>0.51280266  </td><td>0.49762668  </td></tr>
	<tr><th scope=row>Reach.liked</th><td>-0.032504147</td><td>0.17069650  </td><td> 0.814450119</td><td>0.76786285  </td><td> 0.5672738  </td><td> 0.3764792  </td><td> 0.91031585 </td><td> 1.00000000 </td><td>0.63065586  </td><td>0.63552993  </td></tr>
	<tr><th scope=row>People.engaged.liked</th><td> 0.047634357</td><td>0.54921531  </td><td> 0.385474936</td><td>0.35050594  </td><td> 0.9101950  </td><td> 0.5882149  </td><td> 0.51280266 </td><td> 0.63065586 </td><td>1.00000000  </td><td>0.45523195  </td></tr>
	<tr><th scope=row>Total.Interactions</th><td> 0.078846654</td><td>0.07577995  </td><td> 0.492956683</td><td>0.41023113  </td><td> 0.3342666  </td><td> 0.1889253  </td><td> 0.49762668 </td><td> 0.63552993 </td><td>0.45523195  </td><td>1.00000000  </td></tr>
</tbody>
</table>




```R


#Computation of X'X
X_num=as.numeric(unlist(X_num))
X_num=matrix(X_num,ncol=10,byrow = FALSE)
C=t(X_num)%*%(X_num)  # it is [10,10] matrix
eigen_C=(eigen(C))$values
k=max(eigen_C)/min(eigen_C)   
k
# here k is condition number and k=972.91 which is near to 1000 and it is
# strong evidence of Multicollinearity
```


814.511361730341



```R
library(GGally)
```


```R
ggpairs(data.frame(X_num))
car::vif(model3)      
#Some of the VIFs are greater than 10 so we will look into Lasso
```


<dl class=dl-horizontal>
	<dt>Page.total.likes</dt>
		<dd>6.89131217107821</dd>
	<dt>Type</dt>
		<dd>1.85615495056467</dd>
	<dt>Total.Reach</dt>
		<dd>17.9127398432856</dd>
	<dt>Total.Impressions</dt>
		<dd>15.4679446029149</dd>
	<dt>Consumers</dt>
		<dd>17.3036900639922</dd>
	<dt>Consumptions</dt>
		<dd>2.0924967243121</dd>
	<dt>Impressions.liked</dt>
		<dd>15.2042539839826</dd>
	<dt>Reach.liked</dt>
		<dd>22.4658688529344</dd>
	<dt>People.engaged.liked</dt>
		<dd>18.5931103519804</dd>
	<dt>Total.Interactions</dt>
		<dd>2.31655416902239</dd>
	<dt>Category_2</dt>
		<dd>1.71653959923773</dd>
	<dt>Category_3</dt>
		<dd>1.67300651322751</dd>
	<dt>Post.Month_group2</dt>
		<dd>10.068210456104</dd>
	<dt>Post.Month_group3</dt>
		<dd>19.7624989418795</dd>
	<dt>Post.Weekday_weekend</dt>
		<dd>1.08542882710251</dd>
	<dt>Post.Hour_morning</dt>
		<dd>1.28416436212048</dd>
	<dt>Post.Hour_day</dt>
		<dd>1.29514281377956</dd>
	<dt>Post.Hour_evening</dt>
		<dd>1.41479917787441</dd>
	<dt>Paid_1</dt>
		<dd>1.05116534322606</dd>
</dl>




    
![png](output_44_1.png)
    



```R
library(glmnet)
```

    Warning message:
    "package 'glmnet' was built under R version 3.6.3"Loading required package: Matrix
    Loaded glmnet 4.0-2
    


```R
#Lasso to remove multicolinearity + variable selection
xtrain=as.matrix(my_data2[,-1])
ytrain=as.vector(my_data2[,1])
cv.out=cv.glmnet(xtrain,ytrain,type.measure = "mse",alpha=1, family="gaussian")
a=coef(cv.out)[,1]
a
length(a[a!=0]) #17 non zero coefficients
selected_variable=names(a[a!=0])
selected_variable
plot(cv.out,xlab="log(lambda)",ylab="mean squared error")
bestlam=cv.out$lambda.min
bestlam
lasso.pred=predict(cv.out,s=bestlam,newx = as.matrix(X_test))
MAPE(lasso.pred,log(y_test)) #0.0563

lasso_model=lm(formula=z~Type+Total.Impressions+Consumers+Total.Interactions+Post.Month_group3,data=my_data2)
car::vif(lasso_model)
#All VIFs are less than 10 so this indicates multicollinearity has been 
#removed and Variable selection has been applied
```


<dl class=dl-horizontal>
	<dt>(Intercept)</dt>
		<dd>6.56120285329556</dd>
	<dt>Page.total.likes</dt>
		<dd>0</dd>
	<dt>Type</dt>
		<dd>0.0143270568159256</dd>
	<dt>Total.Reach</dt>
		<dd>0</dd>
	<dt>Total.Impressions</dt>
		<dd>0.0419823056159693</dd>
	<dt>Consumers</dt>
		<dd>0.535076279009067</dd>
	<dt>Consumptions</dt>
		<dd>0</dd>
	<dt>Impressions.liked</dt>
		<dd>0</dd>
	<dt>Reach.liked</dt>
		<dd>0</dd>
	<dt>People.engaged.liked</dt>
		<dd>0</dd>
	<dt>Total.Interactions</dt>
		<dd>0.200841449841357</dd>
	<dt>Category_2</dt>
		<dd>0</dd>
	<dt>Category_3</dt>
		<dd>0</dd>
	<dt>Post.Month_group2</dt>
		<dd>0</dd>
	<dt>Post.Month_group3</dt>
		<dd>-0.1686466828926</dd>
	<dt>Post.Weekday_weekend</dt>
		<dd>0</dd>
	<dt>Post.Hour_morning</dt>
		<dd>0</dd>
	<dt>Post.Hour_day</dt>
		<dd>0</dd>
	<dt>Post.Hour_evening</dt>
		<dd>0</dd>
	<dt>Paid_1</dt>
		<dd>0</dd>
</dl>




6



<ol class=list-inline>
	<li>'(Intercept)'</li>
	<li>'Type'</li>
	<li>'Total.Impressions'</li>
	<li>'Consumers'</li>
	<li>'Total.Interactions'</li>
	<li>'Post.Month_group3'</li>
</ol>




0.00743026258414189


    MAPE 0.0561322


<dl class=dl-horizontal>
	<dt>Type</dt>
		<dd>1.47699244618849</dd>
	<dt>Total.Impressions</dt>
		<dd>1.31642247959984</dd>
	<dt>Consumers</dt>
		<dd>1.82148348695721</dd>
	<dt>Total.Interactions</dt>
		<dd>1.28471607350335</dd>
	<dt>Post.Month_group3</dt>
		<dd>1.09646433845824</dd>
</dl>




    
![png](output_46_6.png)
    



```R
bestlam

```


0.00743026258414189



```R

```


```R

```


```R

```


```R

```


```R

```
